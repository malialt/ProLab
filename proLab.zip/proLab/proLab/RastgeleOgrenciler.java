import java.io.*;

public class RastgeleOgrenciler
{
//    private Student[] ogrenciler;
    private Student rastgele;
    
    private File dosya;
    private FileWriter yaz�c�;
    
    
    public RastgeleOgrenciler(int kacTane)
    {
        try
        {
            //Yeni txt dosyas� olu�turma
            dosya = new File("Ogrenciler.txt");
            dosya.createNewFile();
            
            //yeni writer olu�turma
            yaz�c� = new FileWriter(dosya);
            
            //Rastgele ��renciler olu�turup txt dosyas�na yazma
            for(int sayac = 0; sayac < kacTane; sayac++)
            {
                rastgele = new Student();
                yaz�c�.write(rastgele.ogrNoAl() + " " + rastgele.adAl() + " " + rastgele.soyadAl() + " \r\n");
            }
            
            yaz�c�.flush();
            yaz�c�.close();
        }
        
        catch(IOException e)
        {
            System.out.println("hata3");
        }
    }
}
